# 2번
### 변수 선언
myName = 'Hong gil dong'  #이름 입력
myMajor = '지능실감미디어융합'  #학과 입력
myNumber = 220000  #학번 입력

### 출력
print('***변경 전 정보***')
print(myName)
print(myMajor)
print(myNumber)
print()

### 변수 값 변경
myName = 'Na you kyoung'  #이름 재입력
myMajor = '인공지능학부'  #학과 재입력
myNumber = 214499  #학번 재입력

### 출력
print('***변경 후 정보***')
print(myName)
print(myMajor)
print(myNumber)



